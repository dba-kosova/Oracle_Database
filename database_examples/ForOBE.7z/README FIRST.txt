To create the BISAMPLE schema, you must have a connection to an 11g Oracle database from the machine where your BIEE platform is installed. 

You need to create the BISAMPLE schema within that database, and populate it with sample data.

To do so, perform the following steps:

====================================

1. Create the BISAMPLE user/schema. 

Open a connection to the database with system or DBA privileges.

Run the script BISAMPLE_USER.SQL to create the BISAMPLE user/schema.

Once executed, verify that you can successfully connect to the database as user BISAMPLE with password BISAMPLE.

IMPORTANT Note: The BISAMPLE user creation script creates the password BISAMPLE (same as user name). To simplify completion of this tutorial, it is recommended that you do not change this user password.

====================================

2. Load BISAMPLE tables and data

Open a connection to the oracle db with BISAMPLE/BISAMPLE user. 

To create the BISAMPLE tables, run BISAMPLE_SCHEMA_825.SQL.

To populate the tables with data, unzip BISAMPLE_DATA_825.zip and run BISAMPLE_DATA_825.SQL.

====================================

3. Verify

Once the BISAMPLE schema is loaded, verify that the tables have been created and populated by issuing commands in SQL*Plus. For example, SELECT COUNT(*) FROM SAMP_REVENUE_F should return 20000 rows.