set feedback off
select to_char(sysdate, 'dd-mm-yy hh24:mi:ss') ctime from dual;
exit