set feedback off
set serveroutput on
exec dbms_output.put_line('No setup is needed for this scripts.');
exec dbms_output.put_line('It just assumes that scripts 3 has been successfully run.');
exit