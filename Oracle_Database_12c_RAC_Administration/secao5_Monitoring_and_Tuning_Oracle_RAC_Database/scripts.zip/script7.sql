declare
 VSN number ;
begin
   DBMS_LOCK.sleep(20);
end;
/
exit;

